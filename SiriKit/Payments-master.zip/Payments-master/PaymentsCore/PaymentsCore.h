//
//  PaymentsCore.h
//  PaymentsCore
//
//  Created by Sam Symons on 16/06/16.
//  Copyright © 2016 Sam Symons. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for PaymentsCore.
FOUNDATION_EXPORT double PaymentsCoreVersionNumber;

//! Project version string for PaymentsCore.
FOUNDATION_EXPORT const unsigned char PaymentsCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PaymentsCore/PublicHeader.h>


